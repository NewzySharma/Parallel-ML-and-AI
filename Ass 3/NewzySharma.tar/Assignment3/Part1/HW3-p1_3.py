import multiprocessing as mp

def normalize(mylist):
    mini = min(mylist)
    maxi = max(mylist)
    return [(i - mini)/(maxi-mini) for i in mylist]

if __name__ == '__main__':
    pool = mp.Pool(mp.cpu_count())
    list_c = [[2, 3, 4, 5], [6, 9, 10, 12], [11, 12, 13, 14], [21, 24, 25, 26]]
    results = [pool.apply(normalize, args=(l1, )) for l1 in list_c]
    pool.close()
    print(results[:10])
