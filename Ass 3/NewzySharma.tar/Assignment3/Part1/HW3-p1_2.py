import os
import multiprocessing as mp



def run_python(process):
    os.system('python {}'.format(process))

if __name__ == '__main__':
    pool = mp.Pool(processes=3)
    processes = ('script1.py', 'script2.py', 'script3.py')
    pool.map(run_python, processes)
